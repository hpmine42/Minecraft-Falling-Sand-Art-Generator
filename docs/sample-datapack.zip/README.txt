Minecraft Falling Sand Art - 48 x 48
Target: Minecraft Java Edition 26.3 (data pack format 121.0).

1. Copy this ZIP into <world>/datapacks/ (do not unzip it).
2. In game: /reload
3. Stand on the ground block G, look along the desired diagonal, then: /function fallingsand:build
4. Wait for the ready message, then break the lowest torch at the anchor.

The build places 2304 gravity blocks and 2304 torches over 8 ticks.
Height: needed = G + 2 + 2 * (48 - 1) = G + 96. Hard limit Y=319.
Floor mode: none. Start corner: near-left.
No landing water is used.

/function fallingsand:verify  - counts torches at the expected positions.
/function fallingsand:reset   - clears the build + landing volume and disarms.

The pack stores four look-direction variants so every setblock can use ~ coordinates.
Exactly one variant is scheduled, so the world receives 2N setblock commands.
Cleanup kills only dropped torch items (minecraft:torch) inside the build + landing volume every 10 ticks for 300 ticks.
