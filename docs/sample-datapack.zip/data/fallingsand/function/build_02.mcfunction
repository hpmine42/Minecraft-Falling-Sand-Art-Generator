execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:place/se_02
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:place/sw_02
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:place/nw_02
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:place/ne_02
schedule function fallingsand:build_03 1t
