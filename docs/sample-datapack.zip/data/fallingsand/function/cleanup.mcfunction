# Kill dropped torch items inside the build + landing volume only. Never the whole world.
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run positioned ~ ~1 ~ run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:torch"}},dx=48,dy=96,dz=48]
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run positioned ~-47 ~1 ~ run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:torch"}},dx=48,dy=96,dz=48]
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run positioned ~-47 ~1 ~-47 run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:torch"}},dx=48,dy=96,dz=48]
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run positioned ~ ~1 ~-47 run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:torch"}},dx=48,dy=96,dz=48]
scoreboard players remove #fs_cleanup fs 10
execute if score #fs_cleanup fs matches 1.. run schedule function fallingsand:cleanup 10t
execute if score #fs_cleanup fs matches ..0 at @e[tag=fs_anchor,tag=fs_se,limit=1] run forceload remove ~-1 ~-1 ~48 ~48
execute if score #fs_cleanup fs matches ..0 at @e[tag=fs_anchor,tag=fs_sw,limit=1] run forceload remove ~-48 ~-1 ~1 ~48
execute if score #fs_cleanup fs matches ..0 at @e[tag=fs_anchor,tag=fs_nw,limit=1] run forceload remove ~-48 ~-48 ~1 ~1
execute if score #fs_cleanup fs matches ..0 at @e[tag=fs_anchor,tag=fs_ne,limit=1] run forceload remove ~-1 ~-48 ~48 ~1
execute if score #fs_cleanup fs matches ..0 run scoreboard players set #fs_state fs 0
execute if score #fs_cleanup fs matches ..0 run tellraw @a {"text":"Falling-sand cleanup finished. The pack is disarmed; reset removes the build.","color":"green"}
