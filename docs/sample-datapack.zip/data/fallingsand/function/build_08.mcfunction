execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:place/se_08
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:place/sw_08
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:place/nw_08
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:place/ne_08
execute if entity @e[tag=fs_anchor,limit=1] run scoreboard players set #fs_state fs 2
tellraw @a {"text":"Falling-sand art ready. Break the lowest torch at the anchor to collapse it.","color":"green"}
