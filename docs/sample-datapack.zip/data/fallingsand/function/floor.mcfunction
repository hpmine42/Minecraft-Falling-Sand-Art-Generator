# Landing floor dispatch. The anchor is at ground Y under cell (0,0).
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:floor_se
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:floor_sw
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:floor_nw
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:floor_ne
