scoreboard players set #fs_verify fs 0
execute if entity @e[tag=fs_anchor,limit=1] run function fallingsand:verify_count
tellraw @s [{"text":"Torches in the build: "},{"score":{"name":"#fs_verify","objective":"fs"}},{"text":"/2304"}]
