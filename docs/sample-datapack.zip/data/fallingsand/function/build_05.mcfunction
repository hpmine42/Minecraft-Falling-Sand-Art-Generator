execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:place/se_05
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:place/sw_05
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:place/nw_05
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:place/ne_05
schedule function fallingsand:build_06 1t
