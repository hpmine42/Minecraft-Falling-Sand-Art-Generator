# While armed, this is exactly one block check per tick. Idle worlds only test the score.
execute if score #fs_state fs matches 2 at @e[tag=fs_anchor,limit=1] unless block ~ ~1 ~ minecraft:torch run function fallingsand:collapse
