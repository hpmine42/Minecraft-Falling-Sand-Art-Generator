# Flood the landing layer only in the water floor mode.
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:water_se
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:water_sw
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:water_nw
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:water_ne
