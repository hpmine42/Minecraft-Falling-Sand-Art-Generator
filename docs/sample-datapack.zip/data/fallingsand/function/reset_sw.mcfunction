fill ~-47 ~1 ~ ~ ~14 ~47 minecraft:air
fill ~-47 ~15 ~ ~ ~28 ~47 minecraft:air
fill ~-47 ~29 ~ ~ ~42 ~47 minecraft:air
fill ~-47 ~43 ~ ~ ~56 ~47 minecraft:air
fill ~-47 ~57 ~ ~ ~70 ~47 minecraft:air
fill ~-47 ~71 ~ ~ ~84 ~47 minecraft:air
fill ~-47 ~85 ~ ~ ~96 ~47 minecraft:air
