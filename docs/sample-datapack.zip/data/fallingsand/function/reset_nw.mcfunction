fill ~-47 ~1 ~-47 ~ ~14 ~ minecraft:air
fill ~-47 ~15 ~-47 ~ ~28 ~ minecraft:air
fill ~-47 ~29 ~-47 ~ ~42 ~ minecraft:air
fill ~-47 ~43 ~-47 ~ ~56 ~ minecraft:air
fill ~-47 ~57 ~-47 ~ ~70 ~ minecraft:air
fill ~-47 ~71 ~-47 ~ ~84 ~ minecraft:air
fill ~-47 ~85 ~-47 ~ ~96 ~ minecraft:air
