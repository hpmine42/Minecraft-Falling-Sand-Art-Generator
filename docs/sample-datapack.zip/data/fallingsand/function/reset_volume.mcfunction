# Clear the build + landing volume for the active orientation.
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:reset_se
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:reset_sw
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:reset_nw
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:reset_ne
