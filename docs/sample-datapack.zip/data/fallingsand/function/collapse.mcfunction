scoreboard players set #fs_state fs 3
scoreboard players set #fs_cleanup fs 300
function fallingsand:water
schedule function fallingsand:cleanup 10t
tellraw @a {"text":"Root torch gone. Collapsing; torch-item cleanup runs for 300 ticks.","color":"gold"}
