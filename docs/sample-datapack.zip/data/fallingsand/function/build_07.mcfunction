execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:place/se_07
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:place/sw_07
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:place/nw_07
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:place/ne_07
schedule function fallingsand:build_08 1t
