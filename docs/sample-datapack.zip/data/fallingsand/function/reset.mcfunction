scoreboard players set #fs_state fs 0
scoreboard players set #fs_cleanup fs 0
schedule clear fallingsand:cleanup
schedule clear fallingsand:build_01
schedule clear fallingsand:build_02
schedule clear fallingsand:build_03
schedule clear fallingsand:build_04
schedule clear fallingsand:build_05
schedule clear fallingsand:build_06
schedule clear fallingsand:build_07
schedule clear fallingsand:build_08
function fallingsand:reset_volume
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run forceload remove ~-1 ~-1 ~48 ~48
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run forceload remove ~-48 ~-1 ~1 ~48
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run forceload remove ~-48 ~-48 ~1 ~1
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run forceload remove ~-1 ~-48 ~48 ~1
kill @e[tag=fs_anchor,limit=1]
tellraw @s {"text":"Falling-sand build cleared and disarmed.","color":"green"}
