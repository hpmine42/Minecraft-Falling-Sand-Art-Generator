scoreboard objectives add fs dummy
execute unless score #fs_state fs matches 0.. run scoreboard players set #fs_state fs 0
