# Run as a player standing on the ground block G. The anchor is placed at G.
execute if entity @e[tag=fs_anchor,limit=1] run return run tellraw @s {"text":"A falling-sand build is already anchored. Run /function fallingsand:reset first.","color":"red"}
scoreboard players set #fs_state fs 1
execute at @s align xyz run summon minecraft:marker ~ ~-1 ~ {Tags:["fs_anchor"]}
# Snap the look direction to the nearest diagonal so every placement can use ~ coordinates.
execute if entity @s[y_rotation=-90..0] run tag @e[tag=fs_anchor,limit=1,sort=nearest] add fs_se
execute if entity @s[y_rotation=0.0001..90] run tag @e[tag=fs_anchor,limit=1,sort=nearest] add fs_sw
execute if entity @s[y_rotation=90.0001..180] run tag @e[tag=fs_anchor,limit=1,sort=nearest] add fs_nw
execute if entity @s[y_rotation=-180..-90.0001] run tag @e[tag=fs_anchor,limit=1,sort=nearest] add fs_ne
execute as @e[tag=fs_anchor,tag=fs_se,limit=1] at @s run tp @s ~ ~ ~
execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run forceload add ~-1 ~-1 ~48 ~48
execute as @e[tag=fs_anchor,tag=fs_sw,limit=1] at @s run tp @s ~ ~ ~
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run forceload add ~-48 ~-1 ~1 ~48
execute as @e[tag=fs_anchor,tag=fs_nw,limit=1] at @s run tp @s ~ ~ ~
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run forceload add ~-48 ~-48 ~1 ~1
execute as @e[tag=fs_anchor,tag=fs_ne,limit=1] at @s run tp @s ~ ~ ~
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run forceload add ~-1 ~-48 ~48 ~1
function fallingsand:floor
schedule function fallingsand:build_01 1t
tellraw @s {"text":"Building 48x48 falling-sand art over 8 ticks. Do not break the root torch until the ready message.","color":"gold"}
