fill ~ ~1 ~-47 ~47 ~14 ~ minecraft:air
fill ~ ~15 ~-47 ~47 ~28 ~ minecraft:air
fill ~ ~29 ~-47 ~47 ~42 ~ minecraft:air
fill ~ ~43 ~-47 ~47 ~56 ~ minecraft:air
fill ~ ~57 ~-47 ~47 ~70 ~ minecraft:air
fill ~ ~71 ~-47 ~47 ~84 ~ minecraft:air
fill ~ ~85 ~-47 ~47 ~96 ~ minecraft:air
