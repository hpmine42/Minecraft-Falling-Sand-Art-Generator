fill ~ ~1 ~ ~47 ~14 ~47 minecraft:air
fill ~ ~15 ~ ~47 ~28 ~47 minecraft:air
fill ~ ~29 ~ ~47 ~42 ~47 minecraft:air
fill ~ ~43 ~ ~47 ~56 ~47 minecraft:air
fill ~ ~57 ~ ~47 ~70 ~47 minecraft:air
fill ~ ~71 ~ ~47 ~84 ~47 minecraft:air
fill ~ ~85 ~ ~47 ~96 ~47 minecraft:air
