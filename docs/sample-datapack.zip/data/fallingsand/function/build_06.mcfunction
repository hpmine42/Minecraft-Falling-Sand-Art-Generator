execute at @e[tag=fs_anchor,tag=fs_se,limit=1] run function fallingsand:place/se_06
execute at @e[tag=fs_anchor,tag=fs_sw,limit=1] run function fallingsand:place/sw_06
execute at @e[tag=fs_anchor,tag=fs_nw,limit=1] run function fallingsand:place/nw_06
execute at @e[tag=fs_anchor,tag=fs_ne,limit=1] run function fallingsand:place/ne_06
schedule function fallingsand:build_07 1t
